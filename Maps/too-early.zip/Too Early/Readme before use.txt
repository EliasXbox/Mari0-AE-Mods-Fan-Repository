88888  888   888
  8   8   8 8   8
  8   8   8 8   8
  8   8   8 8   8
  8    888   888

88888  888  8888  8    8   8
8     8   8 8   8 8     8 8
888   88888 8   8 8      8
8     8   8 8888  8      8
88888 8   8 8   8 88888  8

This mappack is for Mari0 AE only. You can download this mappack via MediaFire or GameJolt.